/*
 * Revision Control Information
 *
 * $Source$
 * $Author$
 * $Revision$
 * $Date$
 *
 */
/* exported */
extern sm_row *sm_minimum_cover();
